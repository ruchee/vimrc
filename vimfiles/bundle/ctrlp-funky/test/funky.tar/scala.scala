package com.example.foo

import java.io.{File, InputStream}

private[barbaz] object Obj001 {
  def method001: String = {
  }

  /** Merge PYTHONPATHS with the appropriate separator. Ignores blank strings. */
  def method002(arg1: String*): String = {
    return arg1
  }

  private[barbaz] def _method003 {
  }
  private def _method004 {
  }
  public def _method005 {
  }
}
