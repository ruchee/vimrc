funName1 <- function (someVariable) {
  # expression
}

funName2 <- function (someVariable) {
  # expression
}
