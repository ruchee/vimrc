package com.example.foo;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.*;

public class java {

    private boolean pendulum;
    protected boolean pb = false;
    private static final int CONSTANT1 = 1;

    public static void main() {
      return;
    }

    public static final String to_s() {
      return "";
    }

    public java (int x, int y) {
      // constructor
    }

    public void curly_brace_is_next_line()
    {
      return;
    }

    public int multiline1 (int x,
                           int y) {
      return x + y;
    }

    public int multiline2 (int x,
                           int y)
    {
      return x + y;
    }

    public void each (long index) {
      if (index == 0) {
        return;
      }
      // this shouldn't be detected as a method
      else if (index == 1) {
        return;
      }
      else {
        return;
      }
    }

    public String toString () {
        return "A";
    }

    protected int foo() {
      return 0;
    }

    private void bar() {
      return;
    }

    public void singleThrow() throws IOException {
    }

    // https://github.com/tacahiroy/ctrlp-funky/issues/95
    public void multipleThrows() throws IOException, FileNotFoundException, DirectoryNotEmptyException {
    }
}
