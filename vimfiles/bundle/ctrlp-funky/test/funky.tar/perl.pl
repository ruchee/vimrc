package Foo;

use strict;
use warnings;

sub add {
  my $sum = 0;
  map { $sum += $_ } @_;
  $sum;
}

sub multi {
  my $sum = shift;
  map { $sum *= $_ } @_;
  $sum;
}

print add(1, 2, 3), "\n";
print multi(1, 2, 3, 4), "\n";

(sub { print 'anonymous', "\n" })->();
my $s = sub { print 'anon2', "\n" };
&$s;

method _format_response($response) {
  #
}

enum 'Foo::Types' , [qw(
  CH CN CU CY
)];

subtype FooType,
  as Str,
  where {
    my $type = $_;
    grep {/^$type$/} qw( organic mechanical alien )
  },
  message { "[$_] is not a valid Foo type" };

coerce FooFields,
  from Undef,
  via { [] };

sub a {
}
