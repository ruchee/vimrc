function global_func() {
  return true;
}

function global_func2(x, y) {
  return x + y;
}

var f = function() {
  return true;
};

function init(x, y) {
  return function() {
    return x * y;
  };
};

var o = {
  version: 1,
  method1: function() {
    return true;
  }
};

// generator function
function* gfunc(param) {
  // something
}

// ES6 JavaScript style of function/method declaration:
const es6 = {
  func1(p1, p2) {
  }
}

function a ()
{

}

function caller() {
  console.log(o());
  console.log(gfunc(1));
  console.log(a);
}

// Anonymous1
const anonymousFunction1 = () => {
  // ...
}

// Anonymous2
var anonymousFunction2 = props => <span>{props.children}</span>;

// Anonymous3
const a = {};
a.anonymousFunction3 = () => {}
