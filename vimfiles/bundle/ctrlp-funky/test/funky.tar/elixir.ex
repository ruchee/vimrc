defmodule FakeStar do
  def rndnum(len) when is_integer len do
    a = 1
    case a do
      1 -> 'one'
      2 -> 'two'
      _ -> 'more'
    end

    cond do
      1 + 1 == 2 -> 'two'
      1 * 1 == 1 -> 'one'
    end

    if a == 1 do
      IO.puts 'one'
    end

    :crypto.strong_rand_bytes(len)
  end

  def rndstr(len) do
    rndnum(len)
    |> :base64.encode_to_string
    |> to_string
  end

  defp priv_func() do
    IO.puts 'private'
  end

  defmacro this_is_a_macro() do
    IO.puts 'this_is_a_macro'
  end
end
