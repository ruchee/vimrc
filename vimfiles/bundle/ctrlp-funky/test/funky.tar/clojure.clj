(ns tacahiroy
    (:use [clojure.contrib.str-utils2 :only (chomp blank?)]))

(defn get-user-input []
    (loop []
        (print "> ")
        (flush)

        (def input (chomp (read-line)))
        (if (not(blank? input))
            input
            (recur))))

(def private-fu []
    (print "private-fu"))


(def funky-writer
    (proxy [java.io.Writer] []
          (write [buf] nil)
          (close []    nil)
          (flush []    nil)))

; not supported yet
(defmacro noprint
    "Evaluates the given expressions with all printing to *out* silenced."
    [& f]
    `(binding [*out* funky-writer]
         ~@f))
