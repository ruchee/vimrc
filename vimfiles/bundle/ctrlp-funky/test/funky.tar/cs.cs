﻿using System;
using System.Linq;
using System.Text;

namespace com.foo.bar.baz
{
    public abstract class Foo : IFoo
    {
        public string Program1 { get; set; }
        public string Program2 { get; set; }

        protected double _a = 0;
        protected static double _b = 0;
        protected StringBuilder sb = new StringBuilder();

        public Foo(double a)
        {
          _a = a;
            Program1 = "";
            Program2 = "";
        }

        public Foo(double a, double b)
        {
          // do something
        }

        protected bool ProtectedMethod()
        {
          if (_a < 1.0) {
            reutrn true;
          } else {
            return false;
          }
        }

        #region R1

        public double PublicMethod(int x)
        {
          return x + 1;
        }

        public abstract string PublicAbstractMethod();

        #endregion

        protected abstract double ProtectedAbstractMethod(string y);
    }
}
